import { FunctionComponent } from "react";
import styles from "./SectionCardForm.module.css";

const SectionCardForm: FunctionComponent = () => {
  return (
    <div className={styles.vectorParent}>
      <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
      <div className={styles.letsBuild}>{`Let’s Build `}</div>
      <div className={styles.together}>Together</div>
      <div className={styles.pParent}>
        <img className={styles.pIcon} alt="" src="/3p.svg" />
        <div className={styles.contactUs}>Contact Us</div>
      </div>
      <div className={styles.aKnowledge}>A Knowledge</div>
      <img className={styles.vectorIcon1} alt="" src="/vector2.svg" />
    </div>
  );
};

export default SectionCardForm;
