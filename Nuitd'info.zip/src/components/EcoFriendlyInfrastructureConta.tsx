import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./EcoFriendlyInfrastructureConta.module.css";

type EcoFriendlyInfrastructureContaType = {
  imageDimensions?: string;
  imageDimensionsText?: string;
  featureDescription?: string;

  /** Style props */
  propTop?: CSSProperties["top"];
  propWidth?: CSSProperties["width"];
  propHeight?: CSSProperties["height"];
  propWidth1?: CSSProperties["width"];
  propHeight1?: CSSProperties["height"];
};

const EcoFriendlyInfrastructureConta: FunctionComponent<
  EcoFriendlyInfrastructureContaType
> = ({
  imageDimensions,
  imageDimensionsText,
  featureDescription,
  propTop,
  propWidth,
  propHeight,
  propWidth1,
  propHeight1,
}) => {
  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      top: propTop,
    };
  }, [propTop]);

  const emojiObjectsIconStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
      height: propHeight,
    };
  }, [propWidth, propHeight]);

  const adminPanelSettingsIconStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth1,
      height: propHeight1,
    };
  }, [propWidth1, propHeight1]);

  return (
    <div className={styles.frameParent} style={frameDivStyle}>
      <div className={styles.boltParent}>
        <img className={styles.boltIcon} alt="" src="/bolt.svg" />
        <div className={styles.ecoFriendlyInfrastructure}>
          Eco-Friendly Infrastructure
        </div>
        <div className={styles.ourExpertiseIn}>
          Our expertise in sustainable architecture aids in designing
          infrastructure that minimizes environmental impact.
        </div>
      </div>
      <div className={styles.emojiObjectsParent}>
        <img
          className={styles.emojiObjectsIcon}
          alt=""
          src={imageDimensions}
          style={emojiObjectsIconStyle}
        />
        <div className={styles.ecoFriendlyInfrastructure}>
          Predictive Analytics and AI:
        </div>
        <div className={styles.ourAiDrivenModels}>
          Our AI-driven models predict climate patterns...
        </div>
      </div>
      <div className={styles.emojiObjectsParent}>
        <img
          className={styles.adminPanelSettingsIcon}
          alt=""
          src={imageDimensionsText}
          style={adminPanelSettingsIconStyle}
        />
        <div className={styles.ecoFriendlyInfrastructure}>
          {featureDescription}
        </div>
        <div className={styles.ourAiDrivenModels}>
          Our AI-driven models predict climate patterns...
        </div>
      </div>
    </div>
  );
};

export default EcoFriendlyInfrastructureConta;
