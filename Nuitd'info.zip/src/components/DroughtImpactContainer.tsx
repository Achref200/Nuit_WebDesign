import { FunctionComponent } from "react";
import styles from "./DroughtImpactContainer.module.css";

type DroughtImpactContainerType = {
  rectangle3?: string;
  rectangle31?: string;
  rectangle32?: string;
  rectangle33?: string;
};

const DroughtImpactContainer: FunctionComponent<DroughtImpactContainerType> = ({
  rectangle3,
  rectangle31,
  rectangle32,
  rectangle33,
}) => {
  return (
    <div className={styles.articleInner}>
      <div className={styles.frameParent}>
        <div className={styles.rectangleParent}>
          <img className={styles.frameChild} alt="" src={rectangle3} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.frameInner} />
            <div className={styles.droughtAndHisTerribleImpacParent}>
              <b
                className={styles.droughtAndHis}
              >{`Drought and his terrible impact `}</b>
              <div className={styles.groupWrapper}>
                <div className={styles.getAFullArticleParent}>
                  <b className={styles.getAFull}>{`Get a Full Article `}</b>
                  <div
                    className={styles.earthHadImpacted}
                  >{`Earth had impacted of drought `}</div>
                  <div className={styles.exploreItNowParent}>
                    <b className={styles.exploreItNow}>Explore it now</b>
                    <img
                      className={styles.groupIcon}
                      alt=""
                      src="/group-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <img className={styles.vectorIcon} alt="" src="/vector-1.svg" />
          </div>
        </div>
        <div className={styles.rectangleParent}>
          <img className={styles.frameChild} alt="" src={rectangle31} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.frameInner} />
            <div className={styles.droughtAndHisTerribleImpacParent}>
              <b
                className={styles.droughtAndHis}
              >{`Floods and his terrible impact `}</b>
              <div className={styles.groupWrapper}>
                <div className={styles.getAFullArticleParent}>
                  <b className={styles.getAFull}>{`Get a Full Article `}</b>
                  <div
                    className={styles.earthHadImpacted}
                  >{`Earth had impacted of drought `}</div>
                  <div className={styles.exploreItNowGroup}>
                    <b className={styles.exploreItNow}>Explore it now</b>
                    <img
                      className={styles.groupIcon}
                      alt=""
                      src="/group-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <img className={styles.vectorIcon} alt="" src="/vector-1.svg" />
          </div>
        </div>
        <div className={styles.rectangleParent}>
          <img className={styles.frameChild} alt="" src={rectangle32} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.frameInner} />
            <div className={styles.droughtAndHisTerribleImpacParent}>
              <b
                className={styles.earthquakesAndHis}
              >{`Earthquakes and his terrible impact `}</b>
              <div className={styles.groupWrapper}>
                <div className={styles.getAFullArticleParent}>
                  <b className={styles.getAFull}>{`Get a Full Article `}</b>
                  <div
                    className={styles.earthHadImpacted}
                  >{`Earth had impacted of drought `}</div>
                  <div className={styles.exploreItNowParent}>
                    <b className={styles.exploreItNow}>Explore it now</b>
                    <img
                      className={styles.groupIcon}
                      alt=""
                      src="/group-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <img className={styles.vectorIcon} alt="" src="/vector-1.svg" />
          </div>
        </div>
        <div className={styles.rectangleParent}>
          <img className={styles.frameChild} alt="" src={rectangle33} />
          <div className={styles.rectangleGroup}>
            <div className={styles.frameItem} />
            <div className={styles.frameInner} />
            <div className={styles.droughtAndHisTerribleImpacParent}>
              <b
                className={styles.tornadoesAndHis}
              >{`Tornadoes and his terrible impact `}</b>
              <div className={styles.groupWrapper}>
                <div className={styles.getAFullArticleParent}>
                  <b className={styles.getAFull}>{`Get a Full Article `}</b>
                  <div
                    className={styles.earthHadImpacted}
                  >{`Earth had impacted of drought `}</div>
                  <div className={styles.exploreItNowParent}>
                    <b className={styles.exploreItNow}>Explore it now</b>
                    <img
                      className={styles.groupIcon}
                      alt=""
                      src="/group-1.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <img className={styles.vectorIcon} alt="" src="/vector-1.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default DroughtImpactContainer;
