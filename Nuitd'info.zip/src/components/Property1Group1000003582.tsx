import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Property1Group1000003582.module.css";

type Property1Group1000003582Type = {
  imageRemovebgPreview1?: string;

  /** Style props */
  property1Group1000003582Position?: CSSProperties["position"];
  property1Group1000003582Top?: CSSProperties["top"];
  property1Group1000003582Left?: CSSProperties["left"];
  starIconWidth?: CSSProperties["width"];
  starIconLeft?: CSSProperties["left"];
};

const Property1Group1000003582: FunctionComponent<
  Property1Group1000003582Type
> = ({
  imageRemovebgPreview1,
  property1Group1000003582Position,
  property1Group1000003582Top,
  property1Group1000003582Left,
  starIconWidth,
  starIconLeft,
}) => {
  const property1Group1000003582Style: CSSProperties = useMemo(() => {
    return {
      position: property1Group1000003582Position,
      top: property1Group1000003582Top,
      left: property1Group1000003582Left,
    };
  }, [
    property1Group1000003582Position,
    property1Group1000003582Top,
    property1Group1000003582Left,
  ]);

  const starIconStyle: CSSProperties = useMemo(() => {
    return {
      width: starIconWidth,
      left: starIconLeft,
    };
  }, [starIconWidth, starIconLeft]);

  return (
    <div
      className={styles.property1group1000003582}
      style={property1Group1000003582Style}
    >
      <div className={styles.newFeatures}>
        <img className={styles.xmlid17Icon} alt="" src="/xmlid-17.svg" />
        <div className={styles.macos11SafariHeaderDarkParent}>
          <div className={styles.macos11SafariHeaderDark}>
            <img
              className={styles.backgroundIcon}
              alt=""
              src="/background.svg"
            />
            <img className={styles.rightIcon} alt="" src="/right.svg" />
            <div className={styles.center}>
              <div className={styles.vectorParent}>
                <img className={styles.vectorIcon} alt="" src="/vector.svg" />
                <div className={styles.websiteTitle}>
                  <img className={styles.unionIcon} alt="" src="/union.svg" />
                  <img
                    className={styles.refreshaltIcon}
                    alt=""
                    src="/refreshalt.svg"
                  />
                  <div className={styles.mediumSParent}>
                    <img
                      className={styles.mediumSIcon}
                      alt=""
                      src="/mediums.svg"
                    />
                    <div className={styles.url}>
                      <div className={styles.sitenamecom}>stratus.com</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <img className={styles.leftIcon} alt="" src="/left.svg" />
          </div>
          <div className={styles.groupChild} />
          <div className={styles.aboutBlurb}>
            <div className={styles.whatWeServe}> What We serve ?</div>
            <div className={styles.environmentalConsultingExpeContainer}>
              <p className={styles.environmentalConsultingExpe}>
                Environmental Consulting: Expert guidance on sustainable
                practices, regulatory compliance, and eco-friendly initiatives.
              </p>
              <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
              <p className={styles.environmentalConsultingExpe}>
                Technology Solutions: Customized climate monitoring systems,
                predictive analytics tools, and software solutions for informed
                decision-making.
              </p>
              <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
              <p className={styles.environmentalConsultingExpe}>
                Education and Outreach: Workshops, seminars, and campaigns to
                raise awareness and inspire action toward conservation.
              </p>
              <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
              <p className={styles.environmentalConsultingExpe}>
                Partnerships and Collaborations: Collaborating with industry
                partners, institutions, and policymakers to drive impactful
                change.
              </p>
            </div>
          </div>
        </div>
        <div className={styles.fantasticServicesParent}>
          <div className={styles.fantasticServices}>Fantastic Services</div>
          <div className={styles.loremIpsumDolor}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor
            sed tellus massa adipiscing egestas placerat. Condimentum tempor
            lorem eu mi pretium nunc.
          </div>
        </div>
      </div>
      <img
        className={styles.imageRemovebgPreview1Icon}
        alt=""
        src={imageRemovebgPreview1}
      />
      <img
        className={styles.property1group1000003582Child}
        alt=""
        src="/star-2.svg"
        style={starIconStyle}
      />
      <div className={styles.property1group1000003582Item} />
      <div className={styles.property1group1000003582Inner} />
      <div className={styles.ellipseDiv} />
      <div className={styles.property1group1000003582Child1} />
    </div>
  );
};

export default Property1Group1000003582;
