import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./ArticleDefault.module.css";

type ArticleDefaultType = {
  /** Style props */
  articleDefaultPosition?: CSSProperties["position"];
  articleDefaultTop?: CSSProperties["top"];
  articleDefaultLeft?: CSSProperties["left"];
};

const ArticleDefault: FunctionComponent<ArticleDefaultType> = ({
  articleDefaultPosition,
  articleDefaultTop,
  articleDefaultLeft,
}) => {
  const articleDefaultStyle: CSSProperties = useMemo(() => {
    return {
      position: articleDefaultPosition,
      top: articleDefaultTop,
      left: articleDefaultLeft,
    };
  }, [articleDefaultPosition, articleDefaultTop, articleDefaultLeft]);

  return <div className={styles.articledefault} style={articleDefaultStyle} />;
};

export default ArticleDefault;
