import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./ArticlesDefault.module.css";

type ArticlesDefaultType = {
  /** Style props */
  articlesDefaultPosition?: CSSProperties["position"];
  articlesDefaultTop?: CSSProperties["top"];
  articlesDefaultLeft?: CSSProperties["left"];
};

const ArticlesDefault: FunctionComponent<ArticlesDefaultType> = ({
  articlesDefaultPosition,
  articlesDefaultTop,
  articlesDefaultLeft,
}) => {
  const articlesDefaultStyle: CSSProperties = useMemo(() => {
    return {
      position: articlesDefaultPosition,
      top: articlesDefaultTop,
      left: articlesDefaultLeft,
    };
  }, [articlesDefaultPosition, articlesDefaultTop, articlesDefaultLeft]);

  return (
    <div className={styles.articlesdefault} style={articlesDefaultStyle} />
  );
};

export default ArticlesDefault;
