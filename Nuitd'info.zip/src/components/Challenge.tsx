import { FunctionComponent, useCallback } from "react";
import EcoFriendlyInfrastructureConta from "./EcoFriendlyInfrastructureConta";
import Property1NewValue from "./Property1NewValue";
import Servicesvar from "./Servicesvar";
import ArticlesDefault from "./ArticlesDefault";
import ArticleDefault from "./ArticleDefault";
import Property1Variant3 from "./Property1Variant3";
import Property1Group1000003582 from "./Property1Group1000003582";
import styles from "./Challenge.module.css";

const Challenge: FunctionComponent = () => {
  const onFrameContainer58Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='rectangle']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onFrameContainer61Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='groupContainer']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  return (
    <div className={styles.challenge}>
      <img className={styles.bgsIcon} alt="" src="/bgs.svg" />
      <div className={styles.footer}>
        <div className={styles.footer1}>
          <div className={styles.frameParent}>
            <div className={styles.logoWrapper}>
              <div className={styles.logo}>
                <b className={styles.greenland}>
                  <span>G</span>
                  <span className={styles.reen}>reen</span>
                  <span>L</span>
                  <span className={styles.reen}>and</span>
                </b>
              </div>
            </div>
            <div className={styles.socialMediaParent}>
              <div className={styles.socialMedia}>
                <img
                  className={styles.instagramIcIcon}
                  alt=""
                  src="/instagramic.svg"
                />
                <img
                  className={styles.instagramIcIcon}
                  alt=""
                  src="/facebookic.svg"
                />
                <img
                  className={styles.instagramIcIcon}
                  alt=""
                  src="/twitteric.svg"
                />
                <img
                  className={styles.instagramIcIcon}
                  alt=""
                  src="/youtubeic.svg"
                />
              </div>
              <div className={styles.copyright}>
                <div className={styles.allRightReserved}>
                  2023 all right reserved to RetroSquad
                </div>
              </div>
            </div>
          </div>
          <div className={styles.aboutUsSectionParent}>
            <div className={styles.aboutUsSection}>
              <div className={styles.aboutUsTitle}>
                <div className={styles.aboutUs}>About Us</div>
              </div>
              <div className={styles.aboutUsMenu}>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>About</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div
                    className={styles.allRightReserved}
                  >{`Social media `}</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Blog</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div
                    className={styles.allRightReserved}
                  >{`Legal & privacy`}</div>
                </div>
              </div>
            </div>
            <div className={styles.servicesMenu}>
              <div className={styles.aboutUsTitle}>
                <div className={styles.services}>Services</div>
              </div>
              <div className={styles.servicesItem}>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Website</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Contact Us</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Help</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Confidentiality</div>
                </div>
              </div>
            </div>
            <div className={styles.servicesMenu}>
              <div className={styles.aboutUsTitle}>
                <div className={styles.services}>Learn</div>
              </div>
              <div className={styles.servicesItem}>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Who we are ?</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div
                    className={styles.allRightReserved}
                  >{`What we serve ? `}</div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>
                    What are our main focus ?
                  </div>
                </div>
                <div className={styles.aboutUsTitle}>
                  <div className={styles.allRightReserved}>Our updates</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.footerChild} />
      </div>
      <div className={styles.home}>
        <div className={styles.rectangleParent}>
          <div className={styles.groupChild} data-scroll-to="rectangle" />
          <b className={styles.yourGuideOfContainer}>
            <p className={styles.yourGuideOf}>{`Your Guide of `}</p>
            <p className={styles.yourGuideOf}>{`Climate Change `}</p>
          </b>
          <div className={styles.loremIpsumIsContainer}>
            <p
              className={styles.yourGuideOf}
            >{`Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, `}</p>
            <p
              className={styles.yourGuideOf}
            >{`remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop `}</p>
            <p className={styles.yourGuideOf}>
              publishing software like Aldus PageMaker including versions of
              Lorem Ipsum.
            </p>
          </div>
          <div className={styles.greenland1}>
            <span>G</span>
            <span className={styles.reen1}>reen</span>
            <span>L</span>
            <span className={styles.reen1}>and</span>
          </div>
        </div>
        <div className={styles.magnify}>
          <img className={styles.vectorIcon} alt="" src="/vector4.svg" />
          <div className={styles.searchHere}>Search Here</div>
        </div>
        <img className={styles.vectorIcon1} alt="" src="/vector5.svg" />
        <div className={styles.darkMode}>Dark Mode</div>
      </div>
      <div className={styles.questions}>
        <img className={styles.xmlid17Icon} alt="" src="/xmlid-17.svg" />
        <div className={styles.frameGroup} data-scroll-to="groupContainer">
          <div className={styles.haveAQuestionParent}>
            <div className={styles.haveAQuestion}>Have a question?</div>
            <div className={styles.loremIpsumDolor}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            </div>
          </div>
          <div className={styles.tabs}>
            <div className={styles.rectangleGroup}>
              <div className={styles.groupItem} />
              <div className={styles.transactions}>Transactions</div>
            </div>
            <div className={styles.rectangleContainer}>
              <div className={styles.groupInner} />
              <div className={styles.general}>General</div>
            </div>
            <div className={styles.groupDiv}>
              <div className={styles.rectangleDiv} />
              <b className={styles.payments}>Payments</b>
            </div>
            <div className={styles.rectangleParent1}>
              <div className={styles.groupChild1} />
              <b className={styles.payments}>Returns</b>
            </div>
            <div className={styles.rectangleParent2}>
              <div className={styles.groupChild2} />
              <b className={styles.payments}>Careeers</b>
            </div>
          </div>
          <div className={styles.groupParent}>
            <div className={styles.whatIsStratusAndHowDoIUParent}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <div className={styles.loremIpsumDolor1}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. In
                egestas at elementum pretium. Non habitant morbi arcu eu et.
                Velit gravida egestas massa, volutpat mi egestas mauris nulla
                ac. Posuere in mauris feugiat sed porta nisi, ut massa. Leo ut
                massa in commodo, in egestas in ultrices.
              </div>
              <img className={styles.close1Icon} alt="" src="/close-1.svg" />
              <img className={styles.groupChild3} alt="" src="/vector-3.svg" />
            </div>
            <div className={styles.whatIsStratusAndHowDoIUGroup}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <img className={styles.close1Icon1} alt="" src="/close-11.svg" />
              <img className={styles.groupChild4} alt="" src="/vector-3.svg" />
            </div>
            <div className={styles.whatIsStratusAndHowDoIUContainer}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <img className={styles.close1Icon1} alt="" src="/close-11.svg" />
              <img className={styles.groupChild4} alt="" src="/vector-3.svg" />
            </div>
            <div className={styles.whatIsStratusAndHowDoIUParent1}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <img className={styles.close1Icon1} alt="" src="/close-11.svg" />
              <img className={styles.groupChild4} alt="" src="/vector-3.svg" />
            </div>
            <div className={styles.whatIsStratusAndHowDoIUParent2}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <img className={styles.close1Icon1} alt="" src="/close-11.svg" />
              <img className={styles.groupChild4} alt="" src="/vector-3.svg" />
            </div>
            <div className={styles.whatIsStratusAndHowDoIUParent3}>
              <div className={styles.general}>
                What is Stratus and how do I use it?
              </div>
              <img className={styles.close1Icon1} alt="" src="/close-11.svg" />
              <img className={styles.groupChild4} alt="" src="/vector-3.svg" />
            </div>
          </div>
        </div>
      </div>
      <div className={styles.magnify1}>
        <img className={styles.lightModeIcon} alt="" src="/light-mode.svg" />
      </div>
      <div className={styles.allInclusiveParent}>
        <img
          className={styles.allInclusiveIcon}
          alt=""
          src="/all-inclusive.svg"
        />
        <div className={styles.letsGetStarted}>Let’s Get Started</div>
      </div>
      <div className={styles.features}>
        <div className={styles.addsWrapper}>
          <div className={styles.adds}>
            <EcoFriendlyInfrastructureConta
              imageDimensions="/emoji-objects.svg"
              imageDimensionsText="/admin-panel-settings.svg"
              featureDescription="Carbon Footprint Reduction:"
            />
          </div>
        </div>
        <img className={styles.xmlid17Icon1} alt="" src="/xmlid-171.svg" />
        <div className={styles.featuresParent}>
          <div className={styles.haveAQuestion}>Features</div>
          <div className={styles.loremIpsumDolor2}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Porttitor
            sed tellus massa adipiscing egestas placerat. Condimentum tempor
            lorem eu mi pretium nunc.
          </div>
        </div>
        <EcoFriendlyInfrastructureConta
          imageDimensions="/all-inclusive1.svg"
          imageDimensionsText="/all-inclusive2.svg"
          featureDescription="Predictive Analytics and AI:"
          propTop="641px"
          propWidth="108.9px"
          propHeight="108.9px"
          propWidth1="108.9px"
          propHeight1="108.9px"
        />
      </div>
      <Property1NewValue
        property1NewValuePosition="absolute"
        property1NewValueTop="1008px"
        property1NewValueLeft="204px"
      />
      <Servicesvar
        servicesvarPosition="absolute"
        servicesvarTop="3964px"
        servicesvarLeft="72px"
      />
      <ArticlesDefault
        articlesDefaultPosition="absolute"
        articlesDefaultTop="1560px"
        articlesDefaultLeft="195px"
      />
      <ArticleDefault
        articleDefaultPosition="absolute"
        articleDefaultTop="1560px"
        articleDefaultLeft="255px"
      />
      <Property1Variant3
        rectangle3="/rectangle-34@2x.png"
        rectangle31="/rectangle-35@2x.png"
        rectangle32="/rectangle-36@2x.png"
        rectangle33="/rectangle-37@2x.png"
        property1Variant3Position="absolute"
        property1Variant3Top="1583px"
        property1Variant3Left="249px"
      />
      <Property1Group1000003582
        imageRemovebgPreview1="/imageremovebgpreview-11@2x.png"
        property1Group1000003582Position="absolute"
        property1Group1000003582Top="3964px"
        property1Group1000003582Left="58px"
        starIconWidth="72.27%"
        starIconLeft="-3.46%"
      />
      <div className={styles.menu}>
        <div className={styles.menuChild} />
        <div className={styles.frameContainer}>
          <div className={styles.homeWrapper} onClick={onFrameContainer58Click}>
            <div className={styles.articles}>Home</div>
          </div>
          <div className={styles.aboutContainer}>
            <div className={styles.articles}>About</div>
          </div>
          <div className={styles.aboutContainer}>
            <div className={styles.articles}>Articles</div>
          </div>
          <div className={styles.faqsWrapper} onClick={onFrameContainer61Click}>
            <div className={styles.articles}>{`FAQs `}</div>
          </div>
          <div className={styles.aboutContainer}>
            <div className={styles.articles}>Services</div>
          </div>
          <div className={styles.aboutContainer}>
            <div className={styles.articles}>Features</div>
          </div>
        </div>
        <div className={styles.pParent}>
          <img className={styles.pIcon} alt="" src="/3p1.svg" />
          <div className={styles.articles}>Contact Us</div>
        </div>
      </div>
    </div>
  );
};

export default Challenge;
