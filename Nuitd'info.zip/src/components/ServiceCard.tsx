import { FunctionComponent } from "react";
import styles from "./ServiceCard.module.css";

const ServiceCard: FunctionComponent = () => {
  return (
    <div className={styles.macos11SafariHeaderDarkParent}>
      <div className={styles.macos11SafariHeaderDark}>
        <img className={styles.backgroundIcon} alt="" src="/background.svg" />
        <img className={styles.rightIcon} alt="" src="/right.svg" />
        <div className={styles.center}>
          <div className={styles.vectorParent}>
            <img className={styles.vectorIcon} alt="" src="/vector.svg" />
            <div className={styles.websiteTitle}>
              <img className={styles.unionIcon} alt="" src="/union.svg" />
              <img
                className={styles.refreshaltIcon}
                alt=""
                src="/refreshalt.svg"
              />
              <div className={styles.mediumSParent}>
                <img className={styles.mediumSIcon} alt="" src="/mediums.svg" />
                <div className={styles.url}>
                  <div className={styles.sitenamecom}>stratus.com</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <img className={styles.leftIcon} alt="" src="/left.svg" />
      </div>
      <div className={styles.groupChild} />
      <div className={styles.aboutBlurb}>
        <div className={styles.whatWeServe}> What We serve ?</div>
        <div className={styles.environmentalConsultingExpeContainer}>
          <p className={styles.environmentalConsultingExpe}>
            Environmental Consulting: Expert guidance on sustainable practices,
            regulatory compliance, and eco-friendly initiatives.
          </p>
          <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
          <p className={styles.environmentalConsultingExpe}>
            Technology Solutions: Customized climate monitoring systems,
            predictive analytics tools, and software solutions for informed
            decision-making.
          </p>
          <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
          <p className={styles.environmentalConsultingExpe}>
            Education and Outreach: Workshops, seminars, and campaigns to raise
            awareness and inspire action toward conservation.
          </p>
          <p className={styles.environmentalConsultingExpe}>&nbsp;</p>
          <p className={styles.environmentalConsultingExpe}>
            Partnerships and Collaborations: Collaborating with industry
            partners, institutions, and policymakers to drive impactful change.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
