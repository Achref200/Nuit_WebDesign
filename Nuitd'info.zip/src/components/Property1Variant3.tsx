import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Property1Variant3.module.css";

type Property1Variant3Type = {
  rectangle3?: string;
  rectangle31?: string;
  rectangle32?: string;
  rectangle33?: string;

  /** Style props */
  property1Variant3Position?: CSSProperties["position"];
  property1Variant3Top?: CSSProperties["top"];
  property1Variant3Left?: CSSProperties["left"];
};

const Property1Variant3: FunctionComponent<Property1Variant3Type> = ({
  rectangle3,
  rectangle31,
  rectangle32,
  rectangle33,
  property1Variant3Position,
  property1Variant3Top,
  property1Variant3Left,
}) => {
  const property1Variant3Style: CSSProperties = useMemo(() => {
    return {
      position: property1Variant3Position,
      top: property1Variant3Top,
      left: property1Variant3Left,
    };
  }, [property1Variant3Position, property1Variant3Top, property1Variant3Left]);

  return (
    <div className={styles.property1variant3} style={property1Variant3Style}>
      <div className={styles.vectorParent}>
        <img className={styles.vectorIcon} alt="" src="/vector1.svg" />
        <div className={styles.letsBuild}>{`Let’s Build `}</div>
        <div className={styles.together}>Together</div>
        <div className={styles.pParent}>
          <img className={styles.pIcon} alt="" src="/3p.svg" />
          <div className={styles.contactUs}>Contact Us</div>
        </div>
        <div className={styles.aKnowledge}>A Knowledge</div>
        <img className={styles.vectorIcon1} alt="" src="/vector2.svg" />
      </div>
      <div className={styles.property1variant3Inner}>
        <div className={styles.frameParent}>
          <div className={styles.rectangleParent}>
            <img className={styles.frameChild} alt="" src={rectangle3} />
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.frameInner} />
              <div className={styles.droughtAndHisTerribleImpacParent}>
                <b
                  className={styles.droughtAndHis}
                >{`Drought and his terrible impact `}</b>
                <div className={styles.groupWrapper}>
                  <div className={styles.getAFullArticleParent}>
                    <b className={styles.getAFull}>{`Get a Full Article `}</b>
                    <div
                      className={styles.earthHadImpacted}
                    >{`Earth had impacted of drought `}</div>
                    <div className={styles.exploreItNowParent}>
                      <b className={styles.exploreItNow}>Explore it now</b>
                      <img
                        className={styles.groupIcon}
                        alt=""
                        src="/group-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <img className={styles.frameChild1} alt="" src="/vector-1.svg" />
            </div>
          </div>
          <div className={styles.rectangleParent}>
            <img className={styles.frameChild} alt="" src={rectangle31} />
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.frameInner} />
              <div className={styles.droughtAndHisTerribleImpacParent}>
                <b
                  className={styles.droughtAndHis}
                >{`Floods and his terrible impact `}</b>
                <div className={styles.groupWrapper}>
                  <div className={styles.getAFullArticleParent}>
                    <b className={styles.getAFull}>{`Get a Full Article `}</b>
                    <div
                      className={styles.earthHadImpacted}
                    >{`Earth had impacted of drought `}</div>
                    <div className={styles.exploreItNowGroup}>
                      <b className={styles.exploreItNow}>Explore it now</b>
                      <img
                        className={styles.groupIcon}
                        alt=""
                        src="/group-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <img className={styles.frameChild1} alt="" src="/vector-1.svg" />
            </div>
          </div>
          <div className={styles.rectangleParent}>
            <img className={styles.frameChild} alt="" src={rectangle32} />
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.frameInner} />
              <div className={styles.droughtAndHisTerribleImpacParent}>
                <b
                  className={styles.earthquakesAndHis}
                >{`Earthquakes and his terrible impact `}</b>
                <div className={styles.groupWrapper}>
                  <div className={styles.getAFullArticleParent}>
                    <b className={styles.getAFull}>{`Get a Full Article `}</b>
                    <div
                      className={styles.earthHadImpacted}
                    >{`Earth had impacted of drought `}</div>
                    <div className={styles.exploreItNowParent}>
                      <b className={styles.exploreItNow}>Explore it now</b>
                      <img
                        className={styles.groupIcon}
                        alt=""
                        src="/group-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <img className={styles.frameChild1} alt="" src="/vector-1.svg" />
            </div>
          </div>
          <div className={styles.rectangleParent}>
            <img className={styles.frameChild} alt="" src={rectangle33} />
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <div className={styles.frameInner} />
              <div className={styles.droughtAndHisTerribleImpacParent}>
                <b
                  className={styles.tornadoesAndHis}
                >{`Tornadoes and his terrible impact `}</b>
                <div className={styles.groupWrapper}>
                  <div className={styles.getAFullArticleParent}>
                    <b className={styles.getAFull}>{`Get a Full Article `}</b>
                    <div
                      className={styles.earthHadImpacted}
                    >{`Earth had impacted of drought `}</div>
                    <div className={styles.exploreItNowParent}>
                      <b className={styles.exploreItNow}>Explore it now</b>
                      <img
                        className={styles.groupIcon}
                        alt=""
                        src="/group-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <img className={styles.frameChild1} alt="" src="/vector-1.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Property1Variant3;
