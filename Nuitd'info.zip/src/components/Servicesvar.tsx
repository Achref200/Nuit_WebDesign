import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Servicesvar.module.css";

type ServicesvarType = {
  /** Style props */
  servicesvarPosition?: CSSProperties["position"];
  servicesvarTop?: CSSProperties["top"];
  servicesvarLeft?: CSSProperties["left"];
};

const Servicesvar: FunctionComponent<ServicesvarType> = ({
  servicesvarPosition,
  servicesvarTop,
  servicesvarLeft,
}) => {
  const servicesvarStyle: CSSProperties = useMemo(() => {
    return {
      position: servicesvarPosition,
      top: servicesvarTop,
      left: servicesvarLeft,
    };
  }, [servicesvarPosition, servicesvarTop, servicesvarLeft]);

  return <div className={styles.servicesvar} style={servicesvarStyle} />;
};

export default Servicesvar;
