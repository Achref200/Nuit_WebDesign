import { FunctionComponent, useMemo, type CSSProperties } from "react";
import Container from "./Container";
import styles from "./Property1NewValue.module.css";

type Property1NewValueType = {
  /** Style props */
  property1NewValuePosition?: CSSProperties["position"];
  property1NewValueTop?: CSSProperties["top"];
  property1NewValueLeft?: CSSProperties["left"];
};

const Property1NewValue: FunctionComponent<Property1NewValueType> = ({
  property1NewValuePosition,
  property1NewValueTop,
  property1NewValueLeft,
}) => {
  const property1NewValueStyle: CSSProperties = useMemo(() => {
    return {
      position: property1NewValuePosition,
      top: property1NewValueTop,
      left: property1NewValueLeft,
    };
  }, [property1NewValuePosition, property1NewValueTop, property1NewValueLeft]);

  return (
    <div className={styles.property1newValue} style={property1NewValueStyle}>
      <Container />
      <div className={styles.whoWeAreParent}>
        <b className={styles.whoWeAre}>Who We Are ?</b>
        <div className={styles.greenlandWeAreContainer}>
          <p className={styles.greenlandWeAreDrivenByAS}>
            <span className={styles.g}>G</span>
            <span className={styles.reen}>reen</span>
            <span className={styles.l}>L</span>
            <span>
              and we are driven by a singular purpose: to spearhead the defense
              against climate change. Founded by a team of passionate
              individuals dedicated to sustainability and armed with expertise
              in cutting-edge technology, we're committed to revolutionizing how
              we combat environmental challenges.
            </span>
          </p>
          <p className={styles.greenlandWeAreDrivenByAS}>
            Our mission is clear: to develop innovative solutions that mitigate
            the effects of climate change, ensuring a greener, more sustainable
            future for generations to come. We stand at the forefront of the
            climate defense industry, integrating our values of innovation,
            collaboration, and environmental stewardship into everything we do.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Property1NewValue;
