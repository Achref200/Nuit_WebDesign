import { FunctionComponent } from "react";
import styles from "./Container.module.css";

const Container: FunctionComponent = () => {
  return (
    <div className={styles.whatIsHoldingYouToTryParent}>
      <div className={styles.whatIsHolding}>What is holding you to try?</div>
      <img className={styles.vectorIcon} alt="" src="/vector3.svg" />
      <div className={styles.flightsmodeParent}>
        <img className={styles.flightsmodeIcon} alt="" src="/flightsmode.svg" />
        <img
          className={styles.flightsmodeIcon1}
          alt=""
          src="/flightsmode.svg"
        />
        <img className={styles.frameChild} alt="" src="/rectangle-4438.svg" />
        <img className={styles.frameItem} alt="" src="/rectangle-4439.svg" />
        <div className={styles.rectangleParent}>
          <div className={styles.frameInner} />
          <b
            className={styles.whatAreThe}
          >{`What Are the climate change effects ? `}</b>
          <div className={styles.rectangleDiv} />
        </div>
      </div>
      <div className={styles.flightsmodeGroup}>
        <img
          className={styles.flightsmodeIcon2}
          alt=""
          src="/flightsmode.svg"
        />
        <img
          className={styles.flightsmodeIcon3}
          alt=""
          src="/flightsmode.svg"
        />
        <img
          className={styles.rectangleIcon}
          alt=""
          src="/rectangle-4438.svg"
        />
        <img className={styles.frameChild1} alt="" src="/rectangle-4439.svg" />
        <div className={styles.rectangleParent}>
          <div className={styles.frameInner} />
          <b
            className={styles.whatAreThe}
          >{`What Are the climate change effects ? `}</b>
          <div className={styles.rectangleDiv} />
        </div>
      </div>
      <div className={styles.flightsmodeContainer}>
        <img
          className={styles.flightsmodeIcon4}
          alt=""
          src="/flightsmode.svg"
        />
        <img
          className={styles.flightsmodeIcon5}
          alt=""
          src="/flightsmode.svg"
        />
        <img className={styles.frameChild4} alt="" src="/rectangle-4438.svg" />
        <img className={styles.frameChild5} alt="" src="/rectangle-4439.svg" />
        <div className={styles.rectangleParent}>
          <div className={styles.frameInner} />
          <b
            className={styles.whatAreThe}
          >{`What Are the climate change effects ? `}</b>
          <div className={styles.rectangleDiv} />
        </div>
      </div>
    </div>
  );
};

export default Container;
